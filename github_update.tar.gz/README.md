# BitgetVolatilityTrader

Ein fortschrittlicher Trading Bot für den Bitget Futures Markt, der auf die automatische Handlung mit volatilen Altcoins spezialisiert ist.

## Funktionen

- Automatische Identifizierung der Top 5 volatilsten Altcoins
- Fortschrittliche technische Analyse mit mehreren Indikatoren (RSI, MACD, VWAP, OBV, etc.)
- Intelligentes Risikomanagement mit adaptiver Drawdown-Begrenzung
- Webbasiertes Dashboard zur Überwachung und Kontrolle
- Optimierte Trading-Strategien für jeden Coin
- Automatische Position Size Anpassung basierend auf Risiko-Level
- Umfassende Dokumentation mit FAQ-Seite

## Technologie

- Python für die Trading-Logik
- Flask für das Web-Dashboard
- Bitget API Integration
- Telegram Benachrichtigungen
- PostgreSQL Datenbank für Datenmanagement

## Hinweise

- Benötigt mindestens 500 USDT Kapital für optimale Funktionalität
- Trading mit 5x Hebel und 7% Position Size pro Trade (automatisch reduziert bei erhöhtem Risiko)
- Hidden Stop-Loss bei 3,5% und Take-Profit bei 10%
- Maximale Anzahl gleichzeitiger Positionen anpassbar (1-10)

## Updates

- 29.04.2025: FAQ-Seite hinzugefügt mit detaillierten Parametererklärungen
- 29.04.2025: Dashboard-Einstellungen für maximale Positionen implementiert
- 29.04.2025: Kapitalberechnungen basierend auf Risikostufen hinzugefügt