# Schritte zum Hochladen auf GitHub:

1. Klonen des Repositories:
   git clone https://github.com/foozy74/BitgetVolatilityTrader.git

2. Dateien in das geklonte Repository kopieren
   
3. Änderungen committen:
   git add .
   git commit -m "FAQ-Seite und Dashboard-Verbesserungen hinzugefügt"
   
4. Änderungen auf GitHub hochladen:
   git push origin main

Alternativ können Sie die Dateien direkt über die GitHub Web-Oberfläche hochladen.
